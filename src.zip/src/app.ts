import 'dotenv/config';

import { MongoDatabase } from './data/mongo/mongo-database';
import { envs } from './config/envs';
import characterRouter from './routes/character.routes';
import express from 'express';
import locationRouter from './routes/location.routes';
import episodeRouter from './routes/episode.routes';
import usersRouter from './routes/user.routes';

const app = express();

(async()=> {
  await main();
})();

async function main() {

try {
   await MongoDatabase.connect({
    dbName: envs.MONGO_DB_NAME,
    mongoUrl: envs.MONGO_URL,
});
console.log( `MongoDB connected at ${ envs.MONGO_URL }`);
} catch (error) {
  
console.log('MongoDB connection error');
console.log(error);

}

app.use(express.json());
app.use('/api/characters', characterRouter);
app.use('/api/locations', locationRouter);
app.use('api/episode', episodeRouter);
app.use('/api/users', usersRouter);

//Listen
app.listen(envs.PORT, () => {

  console.log(`Server running at port ${ envs.PORT }`);
});



};



