
import { envs } from "../config/envs"
import {Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { UserModel } from '../data/mongo/models/user.model';

const { JWT_SECRET, JWT_EXPIRES_IN } = envs;

export const login = async (req: Request, res: Response ) => {
    try {
        const { email, password } = req.body;

        // Search user by email
        const user = await UserModel.findOne({ email });
        if (!user) return res.status(401).json({ message: "User not found"});

        //Check password
        const isMatch = bcrypt.compareSync(password, user.password);
        if (!isMatch) return res.status(401).json({ message: "Invalid password"});

        //Generate JWT
        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role } ,
        JWT_SECRET, 
    { expiresIn: JWT_EXPIRES_IN as jwt.SignOptions['expiresIn'] }
    );

    return res.json( { token });

} catch (error) {
    console.error(error);
    return res.status(500).json( { message: "Server error"});
}

}




