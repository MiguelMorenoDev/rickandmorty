import {Request, Response } from 'express';
import { CharacterModel } from '../data';

//CREATE
export const createCharacter = async (req: Request, res: Response) => {
    try {
        const newCharacter = await CharacterModel.create(req.body);

        res.status(201).json( newCharacter );

    } catch (error: any) {
        if (error.name === 'ValidationError') {
            return res.status(400).json({
                error: 'Invalid input data',
                details: error.message
            });
        }

        res.status(500).json({ error: 'Internal server error'});
    }
}

// READ all characters
export const getCharacters = async (req: Request, res: Response) => {
  try {

     //Filters
    const filters: any = {};

    if (req.query.name) filters.name = req.query.name;
    if (req.query.status) filters.status = req.query.status;
    if (req.query.species) filters.species = req.query.species;
    if (req.query.type) filters.type = req.query.type;
    if (req.query.gender) filters.gender = req.query.gender;

    const filteredCharacters = await CharacterModel.find(filters);
    res.json(filteredCharacters);
    
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'Error retrieving characters' });
  }
};

//READ 1 character
export const getCharacter = async (req: Request, res: Response) => {

    const { id } = req.params;

    try {
        const character = await CharacterModel.findOne( { id: Number(id) } );
        res.json(character);

        if (!character) {
            return res.status(400).json({ message: 'Character not found'});
        }
    } catch (error) {
            return res.status(500).json({ message: 'Error retrieving character'});
    }
}



//UPDATE
export const updateCharacter = async (req: Request, res: Response) => {

     const { id } = req.params;
      const updateData = req.body;

        try {
            const updatedCharacter = await CharacterModel.findOneAndUpdate(
                { id: Number(id)},
                updateData,
                { new: true }
            );

        if ( !updatedCharacter) {
            return res.status(404).json({ message: 'Character not found'});
        }

        res.json( updatedCharacter );

    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Update failed' });

        }
    }

//DELETE
export const deleteCharacter = async (req: Request, res: Response) => {

    const { id } = req.params;

     try {
         const result =  await CharacterModel.findOneAndDelete({id: Number(id) });

         if ( !result ) {
            return res.status(400).json( { message: 'Character not found'} );
         }

            res.json({ message: 'Character deleted successfully' });

    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Delete failed' });

        }
}
