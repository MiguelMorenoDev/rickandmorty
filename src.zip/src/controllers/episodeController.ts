import { Request, Response } from 'express';
import { EpisodeModel } from '../data/mongo/models/episode.model';

//CREATE

export const createEpisode = async (req: Request, res: Response) => {
try {
        const newEpisode = await EpisodeModel.create(req.body);

} catch (error: any) {
    if (error.name === 'ValidationError') {
        return res.status(400).json({
            error: 'Invalid input data',
            details: error.message
        })
    }

    res.status(500).json({ error: 'Internal server error'});
}

}

//READ all episodes

export const getEpisodes = async (req: Request, res: Response) => {
    try {
        
        //FIlter
        const filters: any = {};

    if (req.query.name) filters.name = req.query.name;
    if (req.query.episodeCode) filters.type = req.query.episodeCode;
   
    const filteredEpisodes = await EpisodeModel.find(filters);
    res.json(filteredEpisodes);
  
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Error retrieving location' });
    }
};

//Read 1 Episode
export const getEpisode = async (req: Request, res: Response) => {
    const { id } = req.params;

 const episode = await EpisodeModel.findOne( { id: Number(id) } );
    try {
       
        res.json(episode);
        
        if (!episode) {
            return res.status(400).json({ message: 'Episode not found'});
        }
    } catch (error) {
        return res.status(400).json({ message: 'Error retrieving episode'});
    }

res.json(episode);
    
}

//UPDATE

export const updateEpisode = async (req: Request, res: Response ) => {
    const { id } = req.params;
    const updateData = req.body;

    try {
        const updatedEpisode = await EpisodeModel.findOneAndUpdate(
            { id: Number(id)},
            updateData,
            { new: true }
        );

        if (!updatedEpisode) {
            return res.status(404).json({ message: 'Episode not found'});
        }

        res.json ( updatedEpisode );

    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Updadate failed' });
    }
}

//DELETE
export const deleteEpisode = async (req: Request, res: Response) => {

    const { id } = req.params;

    try {
        const result = await EpisodeModel.findOneAndDelete({id: Number(id) });

            if (!result) {
                return res.status(400).json( { message: 'Location not found'} );
            }

            res.json({ mssage: 'Location deleted successfully' });

        } catch ( error ) {
            console.log(error);
            res.status(500).json({ message: 'Delete failed' });
        }
       
    }
