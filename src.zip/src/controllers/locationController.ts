import {Request, Response } from 'express';
import { LocationModel } from '../data/mongo/models/location.model';




//CREATE
export const createLocation = async (req: Request, res: Response) => {
    try {
        const newLocation = await LocationModel.create(req.body);

        res.status(201).json( newLocation );

    } catch (error: any) {
        if (error.name === 'ValidationError') {
            return res.status(400).json({
                error: 'Invalid input data',
                details: error.message
            });
        }

        res.status(500).json({ error: 'Internal server error'});
    }
}

// READ all location
export const getLocations = async (req: Request, res: Response) => {
  try {

     //Filter
    const filters: any = {};

    if (req.query.name) filters.name = req.query.name;
    if (req.query.type) filters.type = req.query.type;
    if (req.query.dimension) filters.dimension = req.query.dimension;
  

    const filteredLocations = await LocationModel.find(filters);
    res.json(filteredLocations);




    
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'Error retrieving location' });
  }
};

//READ 1 location
export const getLocation = async (req: Request, res: Response) => {

    const { id } = req.params;

    try {
        const location = await LocationModel.findOne( { id: Number(id) } );
        res.json(location);

        if (!location) {
            return res.status(400).json({ message: 'Location not found'});
        }
    } catch (error) {
            return res.status(500).json({ message: 'Error retrieving location'});
    }

    res.json(location);
}



//UPDATE
export const updateLocation = async (req: Request, res: Response) => {

     const { id } = req.params;
      const updateData = req.body;

        try {
            const updatedLocation = await LocationModel.findOneAndUpdate(
                { id: Number(id)},
                updateData,
                { new: true }
            );

        if ( !updatedLocation) {
            return res.status(404).json({ message: 'Location not found'});
        }

        res.json( updatedLocation );

    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Update failed' });

        }
    }

//DELETE
export const deleteLocation = async (req: Request, res: Response) => {

    const { id } = req.params;

     try {
         const result =  await LocationModel.findOneAndDelete({id: Number(id) });

         if ( !result ) {
            return res.status(400).json( { message: 'Location not found'} );
         }

            res.json({ message: 'Location deleted successfully' });

    } catch (error) {
        console.log(error);
        res.status(500).json({ message: 'Delete failed' });

        }
}
