import { Request, Response } from 'express'; 

import { UserModel } from "../data/mongo/models/user.model";


UserModel
export const getUsers = async (req: Request, res: Response) => {
    try {
        const users = await UserModel.find(); // Excluye passwords
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching users' });
    }
};

