import { Schema, model } from 'mongoose';

const episodeSchema = new Schema({
id: { type: Number, required: true, unique: true },
name: { type: String, required: true },
air_date: { type: String, required: true },
episodeCode: {type: String, required: true},
characters: [{
    type: String,
}],
url:{ type: String, default: "" },
created: { type: Date, default: Date.now }

}); 

export const EpisodeModel =model('model', episodeSchema);