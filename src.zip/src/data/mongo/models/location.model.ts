
import {Schema, model } from 'mongoose';

const locationSchema = new Schema({
    id: { type: Number, required: true, unique: true },
    name: { type: String, required: true },
    type: { type: String, required: true },
    dimension: { type: String, required: true },
    residents: [String],
    gender: { type: String, enum: ['Female', 'Male', 'Genderless', 'unknown'], required: true },
    url: { type: String, default: "" },
    created: String,

});

export const LocationModel = model('Location', locationSchema );