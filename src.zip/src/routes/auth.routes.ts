import { Router } from 'express';
import { login, verifyToken } from '../controllers/authController';
import { authMiddleware } from '../middlewares/auth'; // Asegúrate de tener este middleware

const router = Router();

router.post('/login', login);
router.get('/verify', authMiddleware, verifyToken); // Ruta para probar JWT

export default router;