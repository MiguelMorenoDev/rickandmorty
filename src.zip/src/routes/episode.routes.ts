import { Router } from "express";
import { createEpisode, deleteEpisode, getEpisode, updateEpisode } from "../controllers/episodeController";

const episodeRouter = Router();

episodeRouter.post('/', createEpisode);
episodeRouter.get('/', getEpisode);
episodeRouter.get('/:id', updateEpisode);
episodeRouter.put('/:id', deleteEpisode);

export default episodeRouter;