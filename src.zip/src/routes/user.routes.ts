import { Router } from 'express';
import { getUsers } from '../controllers/userController';

const usersRouter = Router();

usersRouter.get('/', getUsers);

export default usersRouter;