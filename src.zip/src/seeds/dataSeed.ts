import "dotenv/config";
import mongoose from "mongoose";
import { CharacterModel } from "../data";
import charactersData from "./characters.json";


const MONGO_URI = process.env.MONGO_URI;

if (!MONGO_URI) {
    throw new Error('MONGO_URI is not defined as a enviroment variable');
}

const seed = async () => {
    try {

        await mongoose.connect(MONGO_URI);

        const mappedCharacters = charactersData.characters.map(character => ({
            id: character.id,
            name: character.name,
            status: character.status,
            species: character.species,
            type: character.type || "",
            gender: character.gender,
            image: character.image,
              origin: {
             name: character.origin.name || "unknown",  
            url: character.origin.url || ""
            },

               location: {
            name: character.location.name || "unknown",
            url: character.location.url || ""
    },
            episode: character.episode || [],
            url: character.url || "",
            created: character.created

        }));

        await CharacterModel.deleteMany({});
        await CharacterModel.insertMany(mappedCharacters);
        console.log('Seed completed');
        
        await mongoose.disconnect();
        console.log("MongoDB disconected");
        
    } catch (error) {
        console.error('Data seed error', error);
    }
}

seed();